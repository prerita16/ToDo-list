# 🌷 Pastel To-Do List

A cute and simple To-Do List web application built with HTML, CSS and JavaScript.

## Features
- Add new tasks
- Mark tasks as completed
- Delete tasks
- Productivity percentage bar
- Completed/total task counter
- Confetti animation when a task is completed
- Responsive pastel UI

## Technologies
- HTML5
- CSS3
- JavaScript

## How to run
Open `index.html` in a web browser, or open the project folder in VS Code and use Live Server.
