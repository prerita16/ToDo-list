const taskInput = document.getElementById("taskInput");
const addButton = document.getElementById("addButton");
const taskList = document.getElementById("taskList");
const progressPercent = document.getElementById("progressPercent");
const progressFill = document.getElementById("progressFill");
const progressDetails = document.getElementById("progressDetails");

function addTask() {
  const text = taskInput.value.trim();

  if (!text) {
    taskInput.focus();
    return;
  }

  const task = document.createElement("div");
  task.className = "task";

  const taskLeft = document.createElement("div");
  taskLeft.className = "task-left";

  const circle = document.createElement("button");
  circle.className = "circle";
  circle.type = "button";
  circle.setAttribute("aria-label", "Complete task");

  const taskText = document.createElement("span");
  taskText.textContent = text;

  const deleteButton = document.createElement("button");
  deleteButton.className = "delete-btn";
  deleteButton.type = "button";
  deleteButton.textContent = "✖";
  deleteButton.setAttribute("aria-label", "Delete task");

  taskLeft.appendChild(circle);
  taskLeft.appendChild(taskText);
  task.appendChild(taskLeft);
  task.appendChild(deleteButton);
  taskList.appendChild(task);

  circle.addEventListener("click", () => {
    const wasCompleted = task.classList.contains("completed");
    task.classList.toggle("completed");

    if (!wasCompleted) {
      circle.textContent = "✔";
      createConfetti();
    } else {
      circle.textContent = "";
    }

    updateProgress();
  });

  deleteButton.addEventListener("click", () => {
    task.remove();
    updateProgress();
  });

  taskInput.value = "";
  taskInput.focus();
  updateProgress();
}

function updateProgress() {
  const tasks = document.querySelectorAll(".task");
  const completed = document.querySelectorAll(".task.completed");

  const total = tasks.length;
  const done = completed.length;
  const percent = total === 0 ? 0 : Math.round((done / total) * 100);

  progressPercent.textContent = `${percent}%`;
  progressFill.style.width = `${percent}%`;
  progressDetails.textContent = `${done} of ${total} task${total === 1 ? "" : "s"} completed`;
}

function createConfetti() {
  const container = document.getElementById("confettiContainer");
  const pieces = ["🌸", "✨", "💗", "🌷", "⭐", "💜"];

  for (let i = 0; i < 28; i++) {
    const piece = document.createElement("div");
    piece.className = "confetti";
    piece.textContent = pieces[Math.floor(Math.random() * pieces.length)];
    piece.style.left = `${Math.random() * 100}vw`;
    piece.style.fontSize = `${10 + Math.random() * 10}px`;
    piece.style.animationDelay = `${Math.random() * 0.25}s`;
    container.appendChild(piece);

    setTimeout(() => piece.remove(), 1500);
  }
}

addButton.addEventListener("click", addTask);

taskInput.addEventListener("keydown", (event) => {
  if (event.key === "Enter") {
    addTask();
  }
});

updateProgress();
